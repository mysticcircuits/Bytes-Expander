Outline is in .GTL layer

All files made in Eagle Light v.6.5.0 for linux
